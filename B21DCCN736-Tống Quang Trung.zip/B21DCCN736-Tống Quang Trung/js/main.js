(function() {
  const myQuestions = [
    {
      question: '1 + 9=10',
      answers: {
        a: 'true',
        b: 'false'
      },
      multi: false,
      correctAnswer: 'a'
    },
    {
      question:
        '3 + 3 = ...',
      answers: {
        a: '6',
        b: '7',
        c: '8',
        d: '9'
      },
      multi: false,
      correctAnswer: 'a'
    },
    {
      question: '... + ... = 7',
      answers: {
        a: '3 + 4',
        b: '2 + 5',
        c: '9 + 1',
        d: '2 + 2'
      },
      multi: true,
      correctAnswer: 'ab'
    }
  ];

  const app = new App(myQuestions);

  const infoForm = document.getElementById('info-form');
  const quizContainer = document.getElementById('quiz-container');

  infoForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    const fullName = document.getElementById('fullname').value;
    const date = document.getElementById('date').value;
    const studentCode = document.getElementById('code-student').value;
    const classCode = document.getElementById('code-class').value;
    

    infoForm.style.display = 'none';
    quizContainer.style.display = 'block';

    app.start();
  });
})();
