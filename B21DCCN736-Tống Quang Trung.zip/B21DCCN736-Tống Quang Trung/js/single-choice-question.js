class SingleChoiceQuestion extends Question {
  constructor(question, index) {
    super(question, index);
  }

  render() {
    const answers = Object.keys(this.answers).map((value) => {
      return `
        <label>
          <input type="radio" name="question-${this.index}" value="${value}">
        ${value} : ${this.answers[value]}
        </label>`;
    });

    return `
      <div class="slide">
        <div class="question">${this.question}</div>
        <div class="answers"> ${answers.join('')}</div>
      </div>`;
  }
}
